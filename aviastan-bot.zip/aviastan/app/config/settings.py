from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent.parent


class Settings(BaseSettings):
    """Application configuration loaded from environment variables / .env file."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Telegram
    bot_token: str = Field(..., alias="BOT_TOKEN")

    # Travelpayouts
    travelpayouts_token: str = Field(..., alias="TRAVELPOUTS_TOKEN")
    travelpayouts_marker: str = Field(..., alias="TRAVELPOUTS_MARKER")
    travelpayouts_base_url: str = Field(
        default="https://api.travelpayouts.com", alias="TRAVELPOUTS_BASE_URL"
    )
    travelpayouts_affiliate_base_url: str = Field(
        default="https://www.aviasales.com", alias="TRAVELPOUTS_AFFILIATE_BASE_URL"
    )

    # Database
    database_url: str = Field(..., alias="DATABASE_URL")

    # Monitoring / caching
    monitoring_interval_minutes: int = Field(default=15, alias="MONITORING_INTERVAL_MINUTES")
    search_cache_ttl: int = Field(default=900, alias="SEARCH_CACHE_TTL")
    search_history_limit: int = Field(default=20, alias="SEARCH_HISTORY_LIMIT")

    # HTTP client behaviour
    http_timeout_seconds: float = Field(default=15.0, alias="HTTP_TIMEOUT_SECONDS")
    http_max_retries: int = Field(default=3, alias="HTTP_MAX_RETRIES")
    http_retry_backoff_seconds: float = Field(default=1.5, alias="HTTP_RETRY_BACKOFF_SECONDS")

    # Misc
    default_language: str = Field(default="ru", alias="DEFAULT_LANGUAGE")
    default_currency: str = Field(default="USD", alias="DEFAULT_CURRENCY")
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")

    # Data files
    cities_file: Path = Field(default=BASE_DIR / "app" / "data" / "cities.json")
    airlines_file: Path = Field(default=BASE_DIR / "app" / "data" / "airlines.json")
    texts_dir: Path = Field(default=BASE_DIR / "app" / "bot" / "texts")


@lru_cache
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]
