from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.bot.texts import ru as t

CB_BUY_PREFIX = "buy"
CB_TRACK_PREFIX = "track"
CB_SAVE_PREFIX = "save"
CB_BACK_TO_RESULTS = "back_to_results"

CB_NO_RESULTS_CHANGE_DATES = "nores_change_dates"
CB_NO_RESULTS_INCREASE_BUDGET = "nores_increase_budget"
CB_NO_RESULTS_ALLOW_TRANSFERS = "nores_allow_transfers"
CB_NO_RESULTS_TRACK = "nores_track"
CB_NO_RESULTS_MAIN_MENU = "nores_main_menu"

CB_OVER_BUDGET_TRACK = "overbudget_track"


def flight_card_keyboard(flight_index: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text=t.BTN_BUY_TICKET, callback_data=f"{CB_BUY_PREFIX}:{flight_index}")
    builder.button(text=t.BTN_TRACK_PRICE, callback_data=f"{CB_TRACK_PREFIX}:{flight_index}")
    builder.button(text=t.BTN_SAVE_FAVORITE, callback_data=f"{CB_SAVE_PREFIX}:{flight_index}")
    builder.adjust(1, 2)
    return builder.as_markup()


def no_results_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text=t.BTN_CHANGE_DATES, callback_data=CB_NO_RESULTS_CHANGE_DATES)
    builder.button(text=t.BTN_INCREASE_BUDGET, callback_data=CB_NO_RESULTS_INCREASE_BUDGET)
    builder.button(text=t.BTN_ALLOW_TRANSFERS, callback_data=CB_NO_RESULTS_ALLOW_TRANSFERS)
    builder.button(text=t.BTN_TRACK_DIRECTION, callback_data=CB_NO_RESULTS_TRACK)
    builder.button(text=t.BTN_MAIN_MENU, callback_data=CB_NO_RESULTS_MAIN_MENU)
    builder.adjust(1)
    return builder.as_markup()


def over_budget_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text=t.BTN_TRACK_PRICE, callback_data=CB_OVER_BUDGET_TRACK)
    builder.adjust(1)
    return builder.as_markup()
