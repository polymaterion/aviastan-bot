from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.bot.texts import ru as t
from app.services.city_service import City

CB_CITY_PREFIX = "city"
CB_OTHER_CITY = "other_city"
CB_CANCEL_SEARCH = "cancel_search"


def city_choice_keyboard(
    turkmenistan_cities: list[City],
    airlines_destination_cities: list[City],
    popular_transit_cities: list[City],
    *,
    step: str,
) -> InlineKeyboardMarkup:
    """step is 'origin' or 'destination', included in callback_data.

    Показывает три группы городов кнопками (п. обновлённого ТЗ):
    - города Туркменистана;
    - зарубежные направления Turkmenistan Airlines;
    - популярные транзитные города (Россия/Узбекистан и т.п.).
    """
    builder = InlineKeyboardBuilder()

    row_sizes: list[int] = []

    for city in turkmenistan_cities:
        builder.button(
            text=f"🇹🇲 {city.name}", callback_data=f"{CB_CITY_PREFIX}:{step}:{city.iata}"
        )
    if turkmenistan_cities:
        row_sizes.append(len(turkmenistan_cities))

    for city in airlines_destination_cities:
        builder.button(
            text=f"✈️ {city.name}", callback_data=f"{CB_CITY_PREFIX}:{step}:{city.iata}"
        )
    if airlines_destination_cities:
        row_sizes.append(len(airlines_destination_cities))

    for city in popular_transit_cities:
        builder.button(
            text=f"🌍 {city.name}", callback_data=f"{CB_CITY_PREFIX}:{step}:{city.iata}"
        )
    if popular_transit_cities:
        row_sizes.append(len(popular_transit_cities))

    builder.button(text=t.BTN_OTHER_CITY, callback_data=f"{CB_OTHER_CITY}:{step}")
    builder.button(text=t.BTN_CANCEL, callback_data=CB_CANCEL_SEARCH)

    builder.adjust(*row_sizes, 1, 1)
    return builder.as_markup()


def city_variants_keyboard(cities: list[City], *, step: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for city in cities:
        builder.button(
            text=f"{city.name}, {city.country} ({city.iata})",
            callback_data=f"{CB_CITY_PREFIX}:{step}:{city.iata}",
        )
    builder.button(text=t.BTN_CANCEL, callback_data=CB_CANCEL_SEARCH)
    builder.adjust(1)
    return builder.as_markup()
