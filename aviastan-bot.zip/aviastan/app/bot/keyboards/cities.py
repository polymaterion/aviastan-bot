from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.bot.texts import ru as t
from app.services.city_service import City

CB_CITY_PREFIX = "city"
CB_OTHER_CITY = "other_city"
CB_CANCEL_SEARCH = "cancel_search"


def city_choice_keyboard(
    turkmen_cities: list[City],
    foreign_cities: list[City],
    *,
    step: str,
) -> InlineKeyboardMarkup:
    """step is 'origin' or 'destination', included in callback_data."""
    builder = InlineKeyboardBuilder()

    for city in turkmen_cities:
        builder.button(
            text=f"🇹🇲 {city.name}", callback_data=f"{CB_CITY_PREFIX}:{step}:{city.iata}"
        )
    for city in foreign_cities:
        builder.button(
            text=f"🌍 {city.name}", callback_data=f"{CB_CITY_PREFIX}:{step}:{city.iata}"
        )

    builder.button(text=t.BTN_OTHER_CITY, callback_data=f"{CB_OTHER_CITY}:{step}")
    builder.button(text=t.BTN_CANCEL, callback_data=CB_CANCEL_SEARCH)

    builder.adjust(2, 2, 2, 1, 1)
    return builder.as_markup()


def city_variants_keyboard(cities: list[City], *, step: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for city in cities:
        builder.button(
            text=f"{city.name}, {city.country} ({city.iata})",
            callback_data=f"{CB_CITY_PREFIX}:{step}:{city.iata}",
        )
    builder.button(text=t.BTN_CANCEL, callback_data=CB_CANCEL_SEARCH)
    builder.adjust(1)
    return builder.as_markup()
