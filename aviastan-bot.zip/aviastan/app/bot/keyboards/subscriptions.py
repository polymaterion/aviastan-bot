from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.bot.texts import ru as t
from app.database.models import SubscriptionStatus

CB_SUB_PAUSE = "sub_pause"
CB_SUB_RESUME = "sub_resume"
CB_SUB_DELETE = "sub_delete"
CB_SUB_EDIT = "sub_edit"


CB_SUB_EDIT_MAX_PRICE = "sub_edit_max_price"
CB_SUB_EDIT_TOGGLE_DIRECT = "sub_edit_toggle_direct"
CB_SUB_EDIT_REMOVE_MAX_PRICE = "sub_edit_remove_max_price"


def subscription_item_keyboard(subscription_id: int, status: SubscriptionStatus) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text=t.BTN_EDIT, callback_data=f"{CB_SUB_EDIT}:{subscription_id}")

    if status == SubscriptionStatus.ACTIVE:
        builder.button(text=t.BTN_PAUSE, callback_data=f"{CB_SUB_PAUSE}:{subscription_id}")
    else:
        builder.button(text=t.BTN_RESUME, callback_data=f"{CB_SUB_RESUME}:{subscription_id}")

    builder.button(text=t.BTN_DELETE, callback_data=f"{CB_SUB_DELETE}:{subscription_id}")
    builder.adjust(1, 2)
    return builder.as_markup()


def edit_subscription_keyboard(subscription_id: int, has_max_price: bool) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(
        text=t.BTN_EDIT_MAX_PRICE, callback_data=f"{CB_SUB_EDIT_MAX_PRICE}:{subscription_id}"
    )
    if has_max_price:
        builder.button(
            text=t.BTN_EDIT_REMOVE_MAX_PRICE,
            callback_data=f"{CB_SUB_EDIT_REMOVE_MAX_PRICE}:{subscription_id}",
        )
    builder.button(
        text=t.BTN_EDIT_TOGGLE_DIRECT, callback_data=f"{CB_SUB_EDIT_TOGGLE_DIRECT}:{subscription_id}"
    )
    builder.adjust(1)
    return builder.as_markup()
