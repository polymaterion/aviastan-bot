from __future__ import annotations

from app.bot.texts import ru as t
from app.providers.base import FlightResult
from app.services.date_service import format_date_ru


def render_flight_card(flight: FlightResult) -> str:
    date_str = format_date_ru(flight.departure_datetime.date()) if flight.departure_datetime else "-"
    dep_time = flight.departure_datetime.strftime("%H:%M") if flight.departure_datetime else "-"
    arr_time = flight.arrival_datetime.strftime("%H:%M") if flight.arrival_datetime else "-"

    if flight.duration is not None:
        hours, minutes = divmod(flight.duration, 60)
        duration_str = f"{hours} ч {minutes} мин"
    else:
        duration_str = "-"

    if flight.direct is True:
        direct_label = t.DIRECT_LABEL
    elif flight.direct is False:
        direct_label = t.TRANSFER_LABEL
    else:
        direct_label = ""

    return t.FLIGHT_CARD.format(
        airline=flight.airline or "Авиакомпания уточняется",
        origin=flight.origin,
        destination=flight.destination,
        date=date_str,
        departure_time=dep_time,
        arrival_time=arr_time,
        duration=duration_str,
        direct_label=direct_label,
        price=f"{flight.price:.0f}",
        currency=flight.currency,
    )
