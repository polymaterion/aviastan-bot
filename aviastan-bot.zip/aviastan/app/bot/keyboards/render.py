from __future__ import annotations

from datetime import datetime

from app.bot.texts import ru as t
from app.providers.base import FlightResult
from app.services.airline_service import AirlineService
from app.services.city_service import CityService

_MONTHS_RU = {
    1: "января", 2: "февраля", 3: "марта", 4: "апреля", 5: "мая", 6: "июня",
    7: "июля", 8: "августа", 9: "сентября", 10: "октября", 11: "ноября", 12: "декабря",
}


def _format_day_month(dt: datetime) -> str:
    return f"{dt.day} {_MONTHS_RU[dt.month]}"


def _format_duration(minutes: int | None) -> str:
    if minutes is None:
        return "-"
    hours, mins = divmod(minutes, 60)
    if hours and mins:
        return f"{hours} ч {mins} мин"
    if hours:
        return f"{hours} ч"
    return f"{mins} мин"


def _city_name(city_service: CityService, iata: str) -> str:
    city = city_service.get_by_iata(iata)
    return city.name if city is not None else iata


def render_flight_card(
    flight: FlightResult, city_service: CityService, airline_service: AirlineService
) -> str:
    """Строит карточку билета с полными названиями городов и авиакомпанией.

    Travelpayouts (/aviasales/v3/prices_for_dates) отдаёт маршрут одним
    отрезком origin -> destination с числом пересадок (transfers) и
    длительностью полёта - без города пересадки и времени ожидания между
    рейсами. Поэтому карточка показывает "🔁 С пересадкой" одной строкой,
    а не детализирует сегменты, которых у нас просто нет.

    origin_airport/destination_airport - реальные поля ответа API: код
    конкретного аэропорта, который может отличаться от кода города
    (например, Москва MOW -> аэропорт DME/SVO/VKO). Если отличается,
    показываем отдельной строкой.
    """
    airline_display = airline_service.display_name(flight.airline)

    origin_name = _city_name(city_service, flight.origin)
    destination_name = _city_name(city_service, flight.destination)

    date_str = _format_day_month(flight.departure_datetime) if flight.departure_datetime else "-"
    dep_time = flight.departure_datetime.strftime("%H:%M") if flight.departure_datetime else "-"
    arr_time = flight.arrival_datetime.strftime("%H:%M") if flight.arrival_datetime else "-"

    duration_minutes = flight.duration
    if duration_minutes is None and flight.departure_datetime and flight.arrival_datetime:
        duration_minutes = int(
            (flight.arrival_datetime - flight.departure_datetime).total_seconds() // 60
        )

    segment_block = t.FLIGHT_CARD_SEGMENT.format(
        dep_time=dep_time,
        origin_city=origin_name,
        duration=_format_duration(duration_minutes),
        arr_time=arr_time,
        dest_city=destination_name,
    )

    lines = [airline_display, "", date_str, segment_block]

    if flight.origin_airport and flight.origin_airport != flight.origin:
        lines.append(t.FLIGHT_CARD_AIRPORT_NOTE.format(city=origin_name, airport=flight.origin_airport))
    if flight.destination_airport and flight.destination_airport != flight.destination:
        lines.append(
            t.FLIGHT_CARD_AIRPORT_NOTE.format(city=destination_name, airport=flight.destination_airport)
        )

    if flight.direct is False:
        lines.append("")
        lines.append(t.FLIGHT_CARD_HAS_TRANSFERS)

    lines.append("")
    lines.append(t.FLIGHT_CARD_PRICE.format(price=f"{flight.price:.0f}", currency=flight.currency))

    return "\n".join(lines)


def render_subscription_card(subscription, city_service: CityService) -> str:
    """Строит карточку подписки для карусельного фото-экрана «Мои подписки»."""
    origin_name = _city_name(city_service, subscription.origin)
    destination_name = _city_name(city_service, subscription.destination)

    if subscription.flexible:
        date_str = (
            f"{_format_day_month(datetime.combine(subscription.departure_date_from, datetime.min.time()))}"
            f" - {_format_day_month(datetime.combine(subscription.departure_date_to, datetime.min.time()))}"
            if subscription.departure_date_from and subscription.departure_date_to
            else "гибкие даты"
        )
    else:
        date_str = (
            _format_day_month(datetime.combine(subscription.departure_date, datetime.min.time()))
            if subscription.departure_date
            else "-"
        )

    status_label = {
        "active": "🟢 Активна",
        "paused": "⏸ На паузе",
    }.get(subscription.status.value if hasattr(subscription.status, "value") else subscription.status, "")

    price = subscription.last_known_price
    price_line = (
        f"от {price:.0f} {subscription.currency}"
        if price is not None
        else "цена ещё не найдена"
    )

    max_price_line = (
        f"Бюджет: до {subscription.max_price:.0f} {subscription.currency}"
        if subscription.max_price is not None
        else "Бюджет: не ограничен"
    )
    direct_only_line = "Только прямые рейсы" if subscription.direct_only else "Прямые и с пересадкой"

    lines = [
        f"🔔 {origin_name} → {destination_name}",
        "",
        date_str,
        price_line,
        "",
        max_price_line,
        direct_only_line,
        "",
        status_label,
    ]
    return "\n".join(lines)
