from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.bot.texts import ru as t

CB_SETTINGS_LANGUAGE = "settings_language"
CB_SETTINGS_CURRENCY = "settings_currency"
CB_SETTINGS_NOTIFICATIONS_TOGGLE = "settings_notif_toggle"

CB_LANG_PREFIX = "lang"
CB_CURRENCY_PREFIX = "currency"

SUPPORTED_LANGUAGES = [("ru", "🇷🇺 Русский")]  # архитектура позволяет добавить tk/en позже
SUPPORTED_CURRENCIES = [("RUB", "🇷🇺 RUB"), ("USD", "🇺🇸 USD"), ("EUR", "🇪🇺 EUR")]


def settings_menu_keyboard(notifications_enabled: bool) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text=t.BTN_LANGUAGE, callback_data=CB_SETTINGS_LANGUAGE)
    builder.button(text=t.BTN_CURRENCY, callback_data=CB_SETTINGS_CURRENCY)

    status = t.NOTIFICATIONS_ENABLED if notifications_enabled else t.NOTIFICATIONS_DISABLED
    builder.button(
        text=t.NOTIFICATIONS_STATUS.format(status=status),
        callback_data=CB_SETTINGS_NOTIFICATIONS_TOGGLE,
    )
    builder.adjust(1)
    return builder.as_markup()


def language_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for code, label in SUPPORTED_LANGUAGES:
        builder.button(text=label, callback_data=f"{CB_LANG_PREFIX}:{code}")
    builder.adjust(1)
    return builder.as_markup()


def currency_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for code, label in SUPPORTED_CURRENCIES:
        builder.button(text=label, callback_data=f"{CB_CURRENCY_PREFIX}:{code}")
    builder.adjust(3)
    return builder.as_markup()
