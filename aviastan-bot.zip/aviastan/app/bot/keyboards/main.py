from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.bot.texts import ru as t

CB_MAIN_FIND_TICKET = "main_find_ticket"
CB_MAIN_MY_SUBSCRIPTIONS = "main_my_subscriptions"
CB_MAIN_SETTINGS = "main_settings"


def main_menu_keyboard() -> InlineKeyboardMarkup:
    """Главное меню - inline-кнопки на фото-экране (единый UI на всём боте:
    одинаковая ширина карточки/кнопок на каждом экране)."""
    builder = InlineKeyboardBuilder()
    builder.button(text=t.BTN_FIND_TICKET, callback_data=CB_MAIN_FIND_TICKET)
    builder.button(text=t.BTN_MY_SUBSCRIPTIONS, callback_data=CB_MAIN_MY_SUBSCRIPTIONS)
    builder.button(text=t.BTN_SETTINGS, callback_data=CB_MAIN_SETTINGS)
    builder.adjust(1, 2)
    return builder.as_markup()
