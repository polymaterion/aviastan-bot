from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from aiogram.utils.keyboard import ReplyKeyboardBuilder

from app.bot.texts import ru as t


def main_menu_keyboard() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text=t.BTN_FIND_TICKET))
    builder.row(
        KeyboardButton(text=t.BTN_MY_SUBSCRIPTIONS),
        KeyboardButton(text=t.BTN_SETTINGS),
    )
    return builder.as_markup(resize_keyboard=True)
