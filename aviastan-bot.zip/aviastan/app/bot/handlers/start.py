from __future__ import annotations

from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from app.bot.keyboards.main import main_menu_keyboard
from app.bot.screen.manager import start_screen
from app.bot.texts import ru as t

router = Router(name="start")


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    await start_screen(
        bot=message.bot,
        state=state,
        chat_id=message.chat.id,
        caption=t.WELCOME,
        reply_markup=main_menu_keyboard(),
    )
