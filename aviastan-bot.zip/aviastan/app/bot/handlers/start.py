from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from app.bot.keyboards.main import main_menu_keyboard
from app.bot.texts import ru as t

router = Router(name="start")


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(t.WELCOME, reply_markup=main_menu_keyboard())


@router.message(F.text == t.BTN_MAIN_MENU)
async def go_to_main_menu(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(t.MAIN_MENU, reply_markup=main_menu_keyboard())
