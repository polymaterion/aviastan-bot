from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.keyboards.subscriptions import (
    CB_SUB_DELETE,
    CB_SUB_EDIT,
    CB_SUB_EDIT_MAX_PRICE,
    CB_SUB_EDIT_REMOVE_MAX_PRICE,
    CB_SUB_EDIT_TOGGLE_DIRECT,
    CB_SUB_PAUSE,
    CB_SUB_RESUME,
    edit_subscription_keyboard,
    subscription_item_keyboard,
)
from app.bot.states.search import EditSubscriptionState
from app.bot.texts import ru as t
from app.database.models import User
from app.services.date_service import format_date_ru
from app.services.subscription_service import SubscriptionService

router = Router(name="subscriptions")


def _render_edit_menu_text(subscription) -> str:
    max_price_str = (
        f"{subscription.max_price:.0f} {subscription.currency}"
        if subscription.max_price is not None
        else t.NOT_SET
    )
    direct_only_str = t.YES if subscription.direct_only else t.NO
    return t.EDIT_SUBSCRIPTION_MENU.format(
        origin=subscription.origin,
        destination=subscription.destination,
        max_price_str=max_price_str,
        direct_only_str=direct_only_str,
    )


@router.message(F.text == t.BTN_MY_SUBSCRIPTIONS)
async def list_subscriptions(message: Message, user: User, session: AsyncSession) -> None:
    service = SubscriptionService(session)
    subscriptions = await service.list_for_user(user.id)

    if not subscriptions:
        await message.answer(t.MY_SUBSCRIPTIONS_EMPTY)
        return

    await message.answer(t.MY_SUBSCRIPTIONS_HEADER)

    for index, sub in enumerate(subscriptions, start=1):
        date_str = format_date_ru(sub.departure_date) if sub.departure_date else "гибкие даты"
        price = sub.last_known_price if sub.last_known_price is not None else sub.max_price or 0
        line = t.SUBSCRIPTION_LINE.format(
            index=index,
            origin=sub.origin,
            destination=sub.destination,
            date=date_str,
            price=f"{price:.0f}",
            currency=sub.currency,
        )
        await message.answer(line, reply_markup=subscription_item_keyboard(sub.id, sub.status))


@router.callback_query(F.data.startswith(f"{CB_SUB_PAUSE}:"))
async def pause_subscription(callback: CallbackQuery, session: AsyncSession) -> None:
    subscription_id = int(callback.data.split(":", 1)[1])
    service = SubscriptionService(session)
    subscription = await service.get_by_id(subscription_id)
    if subscription is None:
        await callback.answer("Подписка не найдена", show_alert=True)
        return
    await service.pause(subscription)
    await callback.answer(t.SUBSCRIPTION_PAUSED)
    await callback.message.edit_reply_markup(
        reply_markup=subscription_item_keyboard(subscription.id, subscription.status)
    )


@router.callback_query(F.data.startswith(f"{CB_SUB_RESUME}:"))
async def resume_subscription(callback: CallbackQuery, session: AsyncSession) -> None:
    subscription_id = int(callback.data.split(":", 1)[1])
    service = SubscriptionService(session)
    subscription = await service.get_by_id(subscription_id)
    if subscription is None:
        await callback.answer("Подписка не найдена", show_alert=True)
        return
    await service.resume(subscription)
    await callback.answer(t.SUBSCRIPTION_RESUMED)
    await callback.message.edit_reply_markup(
        reply_markup=subscription_item_keyboard(subscription.id, subscription.status)
    )


@router.callback_query(F.data.startswith(f"{CB_SUB_DELETE}:"))
async def delete_subscription(callback: CallbackQuery, session: AsyncSession) -> None:
    subscription_id = int(callback.data.split(":", 1)[1])
    service = SubscriptionService(session)
    subscription = await service.get_by_id(subscription_id)
    if subscription is None:
        await callback.answer("Подписка не найдена", show_alert=True)
        return
    await service.delete(subscription)
    await callback.answer(t.SUBSCRIPTION_DELETED)
    await callback.message.edit_text(t.SUBSCRIPTION_DELETED)


@router.callback_query(F.data.startswith(f"{CB_SUB_EDIT}:"))
async def open_edit_menu(callback: CallbackQuery, session: AsyncSession) -> None:
    subscription_id = int(callback.data.split(":", 1)[1])
    service = SubscriptionService(session)
    subscription = await service.get_by_id(subscription_id)
    if subscription is None:
        await callback.answer("Подписка не найдена", show_alert=True)
        return

    await callback.answer()
    await callback.message.answer(
        _render_edit_menu_text(subscription),
        reply_markup=edit_subscription_keyboard(
            subscription.id, has_max_price=subscription.max_price is not None
        ),
    )


@router.callback_query(F.data.startswith(f"{CB_SUB_EDIT_MAX_PRICE}:"))
async def ask_new_max_price(callback: CallbackQuery, state: FSMContext) -> None:
    subscription_id = int(callback.data.split(":", 1)[1])
    await state.update_data(editing_subscription_id=subscription_id)
    await state.set_state(EditSubscriptionState.waiting_new_max_price)
    await callback.answer()
    await callback.message.answer(t.ASK_NEW_MAX_PRICE)


@router.message(EditSubscriptionState.waiting_new_max_price)
async def new_max_price_entered(message: Message, state: FSMContext, session: AsyncSession) -> None:
    raw = (message.text or "").strip().replace(",", ".")
    try:
        value = float(raw)
        if value <= 0:
            raise ValueError
    except ValueError:
        await message.answer(t.MAX_PRICE_INVALID)
        return

    data = await state.get_data()
    subscription_id = data.get("editing_subscription_id")
    service = SubscriptionService(session)
    subscription = await service.get_by_id(subscription_id)
    if subscription is None:
        await message.answer("Подписка не найдена")
        await state.clear()
        return

    await service.update_max_price(subscription, value)
    await state.clear()
    await message.answer(t.SUBSCRIPTION_UPDATED)
    await message.answer(
        _render_edit_menu_text(subscription),
        reply_markup=edit_subscription_keyboard(subscription.id, has_max_price=True),
    )


@router.callback_query(F.data.startswith(f"{CB_SUB_EDIT_REMOVE_MAX_PRICE}:"))
async def remove_max_price(callback: CallbackQuery, session: AsyncSession) -> None:
    subscription_id = int(callback.data.split(":", 1)[1])
    service = SubscriptionService(session)
    subscription = await service.get_by_id(subscription_id)
    if subscription is None:
        await callback.answer("Подписка не найдена", show_alert=True)
        return

    await service.update_max_price(subscription, None)
    await callback.answer(t.SUBSCRIPTION_UPDATED)
    await callback.message.edit_text(
        _render_edit_menu_text(subscription),
        reply_markup=edit_subscription_keyboard(subscription.id, has_max_price=False),
    )


@router.callback_query(F.data.startswith(f"{CB_SUB_EDIT_TOGGLE_DIRECT}:"))
async def toggle_direct_only(callback: CallbackQuery, session: AsyncSession) -> None:
    subscription_id = int(callback.data.split(":", 1)[1])
    service = SubscriptionService(session)
    subscription = await service.get_by_id(subscription_id)
    if subscription is None:
        await callback.answer("Подписка не найдена", show_alert=True)
        return

    await service.toggle_direct_only(subscription)
    await callback.answer(t.SUBSCRIPTION_UPDATED)
    await callback.message.edit_text(
        _render_edit_menu_text(subscription),
        reply_markup=edit_subscription_keyboard(subscription.id, has_max_price=subscription.max_price is not None),
    )
