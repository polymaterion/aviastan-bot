"""Все текстовые сообщения бота на русском языке.

Вынесены из бизнес-логики, чтобы в будущем добавить другие языки
(туркменский, английский) без переписывания хендлеров.
Используются как .format(...) шаблоны.
"""

# --- Главное меню / старт ---

WELCOME = (
    "✈️ Авиабилеты в Туркменистан\n\n"
    "Найдём подходящие авиабилеты и поможем\n"
    "следить за изменением цены.\n\n"
    "Что хотите сделать?"
)

MAIN_MENU = (
    "✈️ Авиабилеты в Туркменистан\n\n"
    "Найдите подходящий авиабилет или настройте\n"
    "отслеживание цены.\n\n"
    "Выберите действие:"
)

BTN_FIND_TICKET = "🔎 Найти билет"
BTN_MY_SUBSCRIPTIONS = "🔔 Мои подписки"
BTN_SETTINGS = "⚙️ Настройки"
BTN_BACK = "⬅️ Назад"
BTN_CANCEL = "❌ Отмена"
BTN_MAIN_MENU = "⬅️ В главное меню"
BTN_OTHER_CITY = "🌎 Другой город"

# --- Поиск: города ---

ASK_ORIGIN = "🛫 Откуда вылетаете?\n\nВыберите город или введите другой город."
ASK_DESTINATION = "🛬 Куда летите?\n\nВыберите город или введите другой город."
ASK_CITY_MANUAL = "Введите город или аэропорт."
CITY_NOT_FOUND = (
    "😔 Не удалось найти такой город.\n\n"
    "Попробуйте ввести название иначе или на английском языке."
)
CITY_CHOOSE_VARIANT = "Выберите нужный город:"
CITY_VARIANT_LINE = "{flag} {name}, {country}\n{iata}"

# --- Поиск: даты ---

ASK_DATE_TYPE = "📅 Когда летите?\n\nВыберите вариант:"
BTN_EXACT_DATE = "📅 Точная дата"
BTN_FLEXIBLE_DATES = "🔄 Гибкие даты"

ASK_EXACT_DEPARTURE_DATE = (
    "Введите дату вылета в формате:\n\nДД.ММ.ГГ\n\nНапример:\n15.10.26"
)
ASK_FLEXIBLE_DEPARTURE_RANGE = (
    "Введите диапазон дат в формате:\n\n"
    "ДД.ММ.ГГ-ДД.ММ.ГГ\n\nНапример:\n15.10.26-25.10.26"
)
ASK_EXACT_RETURN_DATE = (
    "Введите дату возвращения в формате:\n\nДД.ММ.ГГ\n\nНапример:\n25.10.26"
)
ASK_FLEXIBLE_RETURN_RANGE = (
    "Введите диапазон дат возвращения в формате:\n\n"
    "ДД.ММ.ГГ-ДД.ММ.ГГ\n\nНапример:\n25.10.26-05.11.26"
)

DATE_PARSE_ERROR = (
    "❌ Не удалось распознать дату.\n\n"
    "Введите дату в формате ДД.ММ.ГГ\n\nНапример:\n15.10.26"
)
DATE_RANGE_PARSE_ERROR = (
    "❌ Не удалось распознать диапазон дат.\n\n"
    "Введите диапазон в формате ДД.ММ.ГГ-ДД.ММ.ГГ\n\n"
    "Например:\n15.10.26-25.10.26"
)
DATE_IN_PAST_ERROR = "❌ Дата не может быть в прошлом. Введите другую дату."
DATE_RANGE_INVALID_ORDER_ERROR = (
    "❌ Первая дата диапазона должна быть раньше второй. Попробуйте ещё раз."
)
RETURN_DATE_CONFLICTS_WITH_DEPARTURE = (
    "❌ Дата возвращения не может быть раньше даты вылета. Попробуйте ещё раз."
)

# --- Поиск: обратный билет ---

ASK_ROUND_TRIP = "🔄 Нужен обратный билет?"
BTN_ROUND_TRIP_YES = "Да, туда и обратно"
BTN_ROUND_TRIP_NO = "Нет, только в одну сторону"

# --- Поиск: доп. параметры ---

ASK_FILTERS = (
    "⚙️ Дополнительные параметры\n\n"
    "При необходимости выберите ограничения\n"
    "для поиска."
)
BTN_DIRECT_ONLY_OFF = "🛫 Только прямые"
BTN_DIRECT_ONLY_ON = "✅ Только прямые"
BTN_MAX_PRICE = "💰 Максимальная цена"
BTN_SEARCH = "➡️ Искать"
BTN_SKIP = "⏭ Пропустить"

ASK_MAX_PRICE = "Введите максимальную цену билета.\n\nНапример:\n500"
MAX_PRICE_INVALID = "❌ Введите положительное число, например: 500"

# --- Поиск: выполнение ---

SEARCHING = "🔎 Ищем подходящие билеты...\n\nОткуда: {origin}\nКуда: {destination}\nДата: {date}"

SEARCH_API_ERROR = (
    "⚠️ Не удалось получить данные о билетах.\n\n"
    "Попробуйте повторить поиск немного позже."
)

NO_RESULTS = (
    "😔 Подходящих билетов не найдено.\n\n"
    "Попробуйте изменить параметры поиска."
)
BTN_CHANGE_DATES = "🔄 Изменить даты"
BTN_INCREASE_BUDGET = "💰 Увеличить бюджет"
BTN_ALLOW_TRANSFERS = "🛫 Разрешить пересадки"
BTN_TRACK_DIRECTION = "🔔 Следить за направлением"

OVER_BUDGET_RESULTS = (
    "💰 Подходящих билетов в пределах\n"
    "вашего бюджета сейчас нет.\n\n"
    "Самый дешёвый вариант:\n{cheapest_price} {currency}\n\n"
    "Можно включить отслеживание и получить\n"
    "уведомление, когда появится более дешёвый билет."
)

# --- Карточка билета ---

FLIGHT_CARD = (
    "✈️ {airline}\n\n"
    "{origin} → {destination}\n\n"
    "📅 {date}\n"
    "🕐 {departure_time} → {arrival_time}\n"
    "⏱ {duration}\n"
    "{direct_label}\n\n"
    "💰 {price} {currency}"
)
DIRECT_LABEL = "🛫 Прямой"
TRANSFER_LABEL = "🔁 С пересадкой"

BTN_BUY_TICKET = "🎫 Купить билет"
BTN_TRACK_PRICE = "🔔 Следить за ценой"
BTN_SAVE_FAVORITE = "❤️ Сохранить"
BTN_BACK_TO_RESULTS = "⬅️ Назад к результатам"

# --- Подписки ---

SUBSCRIPTION_CREATED = (
    "🔔 Подписка создана\n\n"
    "Я буду отслеживать подходящие билеты\n"
    "по этому направлению и сообщать об изменениях.\n\n"
    "Маршрут:\n{origin} → {destination}\n\n"
    "Дата:\n{date}\n\n"
    "{max_price_line}"
)
SUBSCRIPTION_MAX_PRICE_LINE = "Максимальная цена:\n{max_price} {currency}"
SUBSCRIPTION_NO_MAX_PRICE_LINE = "Максимальная цена не ограничена."

SUBSCRIPTION_CREATED_EMPTY = (
    "🔔 Отслеживание включено\n\n"
    "Сейчас подходящих билетов нет.\n"
    "Я сообщу, когда появится подходящий вариант."
)

MY_SUBSCRIPTIONS_HEADER = "🔔 Мои подписки"
MY_SUBSCRIPTIONS_EMPTY = (
    "🔔 Мои подписки\n\n"
    "У вас пока нет активных подписок.\n"
    "Найдите билет и нажмите «Следить за ценой»."
)
SUBSCRIPTION_LINE = "{index}. {origin} → {destination}\n{date}\nот {price} {currency}"

BTN_EDIT = "✏️ Изменить"
BTN_PAUSE = "⏸ Приостановить"
BTN_RESUME = "▶️ Возобновить"
BTN_DELETE = "🗑 Удалить"

EDIT_SUBSCRIPTION_MENU = (
    "✏️ Изменение подписки\n\n"
    "{origin} → {destination}\n"
    "Текущая максимальная цена: {max_price_str}\n"
    "Только прямые рейсы: {direct_only_str}"
)
BTN_EDIT_MAX_PRICE = "💰 Изменить максимальную цену"
BTN_EDIT_TOGGLE_DIRECT = "🛫 Переключить «Только прямые»"
BTN_EDIT_REMOVE_MAX_PRICE = "♾️ Убрать ограничение цены"
ASK_NEW_MAX_PRICE = "Введите новую максимальную цену.\n\nНапример:\n400"
NOT_SET = "не задана"
YES = "да"
NO = "нет"
SUBSCRIPTION_UPDATED = "✏️ Подписка обновлена."

SUBSCRIPTION_PAUSED = "⏸ Подписка приостановлена."
SUBSCRIPTION_RESUMED = "▶️ Подписка возобновлена."
SUBSCRIPTION_DELETED = "🗑 Подписка удалена."

# --- Уведомления ---

NOTIFY_NEW_FLIGHT = (
    "✈️ Найден новый подходящий билет\n\n"
    "{origin} → {destination}\n{date}\n\n"
    "💰 {price} {currency}"
)
NOTIFY_PRICE_DROP = (
    "📉 Цена снизилась\n\n"
    "{origin} → {destination}\n{date}\n\n"
    "Было: {old_price} {currency}\n"
    "Стало: {new_price} {currency}"
)
NOTIFY_FLIGHT_BACK = (
    "🔔 Билет снова доступен\n\n"
    "{origin} → {destination}\n{date}\n\n"
    "💰 {price} {currency}"
)

# --- Настройки ---

SETTINGS_MENU = "⚙️ Настройки"
BTN_LANGUAGE = "🌐 Язык"
BTN_CURRENCY = "💱 Валюта"
BTN_NOTIFICATIONS = "🔔 Уведомления"

CHOOSE_LANGUAGE = "Выберите язык интерфейса:"
CHOOSE_CURRENCY = "Выберите валюту отображения цен:"
NOTIFICATIONS_STATUS = "🔔 Уведомления: {status}"
NOTIFICATIONS_ENABLED = "включены"
NOTIFICATIONS_DISABLED = "отключены"

# --- Общее ---

SEARCH_CANCELLED = "Поиск отменён."
UNKNOWN_COMMAND = "Не понял команду. Пожалуйста, используйте кнопки меню."
