from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass(slots=True, frozen=True)
class City:
    name: str
    country: str
    iata: str
    aliases: tuple[str, ...]


class CityService:
    """Загружает и ищет города из data/cities.json и data/popular_cities.json
    (п.10, п.47 ТЗ). Список городов не хранится в коде.
    """

    def __init__(self, cities_file: Path, popular_cities_file: Path) -> None:
        self._cities_file = cities_file
        self._popular_cities_file = popular_cities_file
        self._cities: list[City] = []
        self._by_iata: dict[str, City] = {}
        self._popular_raw: dict = {}
        self._load()

    def _load(self) -> None:
        with open(self._cities_file, encoding="utf-8") as f:
            raw = json.load(f)
        self._cities = [
            City(
                name=c["name"],
                country=c["country"],
                iata=c["iata"],
                aliases=tuple(c.get("aliases", [])),
            )
            for c in raw
        ]
        self._by_iata = {c.iata: c for c in self._cities}

        with open(self._popular_cities_file, encoding="utf-8") as f:
            self._popular_raw = json.load(f)

    def reload(self) -> None:
        self._load()

    def get_by_iata(self, iata: str) -> City | None:
        return self._by_iata.get(iata.upper())

    def get_popular(self) -> tuple[list[City], list[City]]:
        """Возвращает (туркменские города, зарубежные города) для быстрого выбора."""
        turkmen = [
            self._by_iata[entry["iata"]]
            for entry in self._popular_raw.get("turkmenistan", [])
            if entry["iata"] in self._by_iata
        ]
        foreign = [
            self._by_iata[entry["iata"]]
            for entry in self._popular_raw.get("foreign", [])
            if entry["iata"] in self._by_iata
        ]
        return turkmen, foreign

    @staticmethod
    def _normalize(text: str) -> str:
        return text.strip().lower().replace("ё", "е")

    def search(self, query: str, limit: int = 5) -> list[City]:
        """Пошаговый поиск (п.47 ТЗ):
        1. нормализация строки
        2. точное совпадение по имени/alias
        3. совпадение по alias (регистронезависимо)
        4. частичное совпадение (вхождение подстроки)
        """
        normalized_query = self._normalize(query)
        if not normalized_query:
            return []

        exact_matches: list[City] = []
        alias_matches: list[City] = []
        partial_matches: list[City] = []

        for city in self._cities:
            normalized_name = self._normalize(city.name)
            normalized_aliases = [self._normalize(a) for a in city.aliases]
            normalized_iata = self._normalize(city.iata)

            if normalized_query == normalized_name or normalized_query == normalized_iata:
                exact_matches.append(city)
                continue
            if normalized_query in normalized_aliases:
                alias_matches.append(city)
                continue
            # Частичное совпадение - только по началу слова (имя города,
            # алиас, либо начало любого слова в многословном названии),
            # чтобы избежать случайных совпадений произвольной подстроки
            # (например, "ашх" не должно совпадать с "дашховуз").
            name_words = normalized_name.split()
            alias_words = [word for alias in normalized_aliases for word in alias.split()]
            all_words = [normalized_name, *normalized_aliases, *name_words, *alias_words]
            if any(word.startswith(normalized_query) for word in all_words):
                partial_matches.append(city)

        ordered = exact_matches + alias_matches + partial_matches
        # de-duplicate while preserving order
        seen: set[str] = set()
        result: list[City] = []
        for city in ordered:
            key = f"{city.iata}"
            if key in seen:
                continue
            seen.add(key)
            result.append(city)
            if len(result) >= limit:
                break
        return result
