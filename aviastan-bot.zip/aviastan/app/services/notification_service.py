from __future__ import annotations

import logging
from typing import Callable

from aiogram import Bot
from aiogram.exceptions import TelegramAPIError
from sqlalchemy.ext.asyncio import AsyncSession

from app.bot.texts import ru as t
from app.database.models import NotificationType, Subscription
from app.database.repositories.flight_repository import FlightRepository
from app.database.repositories.subscription_repository import SubscriptionRepository
from app.providers.base import FlightResult
from app.services.date_service import format_date_ru

logger = logging.getLogger(__name__)

# Валюта -> минимальное изменение цены, при котором отправляется
# уведомление о снижении. "300" в рублях и "300" в долларах - совершенно
# разная величина, поэтому порог задаётся отдельно на каждую валюту, а
# не одним универсальным числом.
DEFAULT_PRICE_DROP_THRESHOLDS: dict[str, float] = {"RUB": 300.0, "USD": 5.0, "EUR": 5.0}
DEFAULT_PRICE_DROP_FALLBACK = 5.0


def default_threshold_resolver(currency: str) -> float:
    return DEFAULT_PRICE_DROP_THRESHOLDS.get(currency.upper(), DEFAULT_PRICE_DROP_FALLBACK)


class NotificationService:
    """Отправляет уведомления и защищает от повторных алертов (п.35-36 ТЗ).

    Логика сравнения предыдущего/нового состояния:
    - было недоступно, стало доступно -> "новый билет" или "снова доступен"
      (уведомление отправляется всегда, порог цены здесь не применяется -
      пользователь должен узнать о появлении билета в любом случае);
    - цена снизилась БОЛЬШЕ чем порог для данной валюты -> "цена снизилась";
    - цена снизилась незначительно, не изменилась или выросла -> без
      уведомления, чтобы не заваливать пользователя уведомлениями о
      колебаниях цены на несколько рублей/долларов.
    """

    def __init__(
        self,
        bot: Bot,
        session: AsyncSession,
        threshold_resolver: Callable[[str], float] = default_threshold_resolver,
    ) -> None:
        self._bot = bot
        self._session = session
        self._flight_repo = FlightRepository(session)
        self._subscription_repo = SubscriptionRepository(session)
        self._threshold_resolver = threshold_resolver

    async def process_subscription_result(
        self,
        subscription: Subscription,
        best_result: FlightResult | None,
        flight_id: int | None,
        telegram_id: int,
        notifications_enabled: bool,
    ) -> None:
        was_available = subscription.last_seen_available
        previous_price = subscription.last_known_price

        if best_result is None:
            # Ничего подходящего не найдено сейчас - просто фиксируем состояние.
            await self._subscription_repo.update_last_known_state(
                subscription, price=None, flight_id=None, available=False
            )
            return

        new_price = best_result.price
        date_str = (
            format_date_ru(best_result.departure_datetime.date())
            if best_result.departure_datetime
            else "-"
        )

        notification_type: NotificationType | None = None

        if not was_available:
            notification_type = (
                NotificationType.FLIGHT_BACK if previous_price is not None else NotificationType.NEW_FLIGHT
            )
        elif previous_price is not None:
            threshold = self._threshold_resolver(best_result.currency)
            if (previous_price - new_price) > threshold:
                notification_type = NotificationType.PRICE_DROP
        # else: цена не изменилась, выросла, или снизилась незначительно
        # (меньше порога для данной валюты) -> без уведомления (п.36 ТЗ)

        await self._flight_repo.record_price_history(
            flight_id=flight_id,
            subscription_id=subscription.id,
            price=new_price,
            currency=best_result.currency,
        )

        await self._subscription_repo.update_last_known_state(
            subscription, price=new_price, flight_id=flight_id, available=True
        )

        if notification_type is None:
            return

        if notifications_enabled:
            await self._send_notification(
                telegram_id=telegram_id,
                notification_type=notification_type,
                origin=best_result.origin,
                destination=best_result.destination,
                date_str=date_str,
                price=new_price,
                previous_price=previous_price,
                currency=best_result.currency,
            )

        await self._flight_repo.add_notification(
            user_id=subscription.user_id,
            subscription_id=subscription.id,
            flight_id=flight_id,
            type_=notification_type,
            price=new_price,
        )

    async def _send_notification(
        self,
        *,
        telegram_id: int,
        notification_type: NotificationType,
        origin: str,
        destination: str,
        date_str: str,
        price: float,
        previous_price: float | None,
        currency: str,
    ) -> None:
        if notification_type == NotificationType.NEW_FLIGHT:
            text = t.NOTIFY_NEW_FLIGHT.format(
                origin=origin, destination=destination, date=date_str, price=price, currency=currency
            )
        elif notification_type == NotificationType.PRICE_DROP:
            text = t.NOTIFY_PRICE_DROP.format(
                origin=origin,
                destination=destination,
                date=date_str,
                old_price=previous_price,
                new_price=price,
                currency=currency,
            )
        else:
            text = t.NOTIFY_FLIGHT_BACK.format(
                origin=origin, destination=destination, date=date_str, price=price, currency=currency
            )

        try:
            await self._bot.send_message(telegram_id, text)
        except TelegramAPIError as exc:
            logger.warning(
                "notification_send_failed", extra={"telegram_id": telegram_id, "error": str(exc)}
            )
