from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import User


class UserRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_by_telegram_id(self, telegram_id: int) -> User | None:
        result = await self.session.execute(
            select(User).where(User.telegram_id == telegram_id)
        )
        return result.scalar_one_or_none()

    async def get_or_create(
        self, telegram_id: int, default_language: str = "ru", default_currency: str = "USD"
    ) -> User:
        user = await self.get_by_telegram_id(telegram_id)
        if user is not None:
            return user
        user = User(
            telegram_id=telegram_id,
            language=default_language,
            currency=default_currency,
        )
        self.session.add(user)
        await self.session.flush()
        return user

    async def update_language(self, user: User, language: str) -> None:
        user.language = language
        await self.session.flush()

    async def update_currency(self, user: User, currency: str) -> None:
        user.currency = currency
        await self.session.flush()

    async def toggle_notifications(self, user: User, enabled: bool) -> None:
        user.notifications_enabled = enabled
        await self.session.flush()
