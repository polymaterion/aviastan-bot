from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional

from app.providers.base import FlightResult

PROVIDER_NAME = "travelpayouts"


def _parse_iso_datetime(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        return None


def parse_prices_for_dates_item(
    item: dict[str, Any],
    *,
    origin: str,
    destination: str,
    currency: str,
    affiliate_link_builder,
) -> FlightResult:
    """Приводит один элемент ответа /aviasales/v3/prices_for_dates к
    единому внутреннему формату FlightResult (п.24 ТЗ). Отсутствующие или
    недостоверные поля становятся None.

    Этот эндпоинт отдаёт агрегированные данные о рейсе (число пересадок,
    суммарную длительность) - без города пересадки, времени ожидания
    между рейсами или смены аэропорта, поэтому такие поля здесь не
    парсятся.
    """
    external_id = str(
        item.get("flight_number")
        or item.get("link")
        or f"{origin}-{destination}-{item.get('departure_at', '')}"
    )

    transfers = item.get("transfers")
    direct: Optional[bool] = None
    if transfers is not None:
        direct = transfers == 0

    duration_val = item.get("duration") or item.get("duration_to")
    duration = int(duration_val) if isinstance(duration_val, (int, float)) else None

    price_val = item.get("price")
    price = float(price_val) if price_val is not None else 0.0

    booking_path = item.get("link")
    booking_url = affiliate_link_builder(booking_path) if booking_path else None

    return FlightResult(
        external_id=external_id,
        provider=PROVIDER_NAME,
        airline=item.get("airline"),
        flight_number=item.get("flight_number"),
        origin=item.get("origin", origin),
        destination=item.get("destination", destination),
        departure_datetime=_parse_iso_datetime(item.get("departure_at")),
        arrival_datetime=_parse_iso_datetime(item.get("arrival_at")),
        return_departure_datetime=_parse_iso_datetime(item.get("return_at")),
        return_arrival_datetime=None,
        price=price,
        currency=currency.upper(),
        direct=direct,
        duration=duration,
        baggage=None,  # Travelpayouts не предоставляет достоверную информацию о багаже в этом эндпоинте
        booking_url=booking_url,
        parsed_at=datetime.now(timezone.utc),
    )


def parse_prices_for_dates_response(
    payload: dict[str, Any],
    *,
    origin: str,
    destination: str,
    currency: str,
    affiliate_link_builder,
) -> list[FlightResult]:
    data = payload.get("data") or []
    return [
        parse_prices_for_dates_item(
            item,
            origin=origin,
            destination=destination,
            currency=currency,
            affiliate_link_builder=affiliate_link_builder,
        )
        for item in data
        if isinstance(item, dict)
    ]
